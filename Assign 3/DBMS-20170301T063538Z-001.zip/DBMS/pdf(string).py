import pdfkit


body = '<html>\
      <head>\
        <meta name="pdfkit-page-size" content="Legal"/>\
        <meta name="pdfkit-orientation" content="Landscape"/>\
      </head>\
      Hello World!\
      </html>'
pdfkit.from_string(body, 'out.pdf') #with --page-size=Legal and --orientation=Landscape